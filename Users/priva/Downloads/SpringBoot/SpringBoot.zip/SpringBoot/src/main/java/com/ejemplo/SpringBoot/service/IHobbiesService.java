/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.ejemplo.SpringBoot.service;

import com.ejemplo.SpringBoot.model.Hobbies;
import java.util.List;

/**
 *
 * @author priva
 */
public interface IHobbiesService {
    
public List<Hobbies> verHobbies();
    
    public void crearHobbies(Hobbies hobb);
    
    public void borrarHobbies(Long id);
    
    public Hobbies buscarHobbies(Long id);
    
    public void modificarHobbiues(Hobbies hobb);
}
